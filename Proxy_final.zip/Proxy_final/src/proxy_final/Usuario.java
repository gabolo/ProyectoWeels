/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxy_final;

/**
 *
 * @author ASUS PC
 */
public class Usuario {
    String usuario;
    String contreseña;
    
    public Usuario(String usuario, String contraseña)
    {
        this.usuario=usuario;
        this.contreseña=contraseña;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContreseña() {
        return contreseña;
    }

    public void setContreseña(String contreseña) {
        this.contreseña = contreseña;
    }




}
